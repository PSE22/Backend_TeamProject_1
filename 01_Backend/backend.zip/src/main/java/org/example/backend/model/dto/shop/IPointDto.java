package org.example.backend.model.dto.shop;

/**
 * packageName : org.example.backendproject.model.dto.shop
 * fileName : IPointDto
 * author : SAMSUNG
 * date : 2024-05-04
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2024-05-04         SAMSUNG          최초 생성
 */
public interface IPointDto {
    Integer getResultPoint();
}
